<!--	PASSWORD: kittySpinny@kitty.com
		USERNAME: kitty123
-->
<!doctype html>
<html>
<?php
session_start();
/*
USED FOR DEBUGGING SESSION VARIABLES

if (isset($_SESSION)) {
	echo '<pre>'; var_dump($_SESSION); echo '</pre>';
	echo '<pre>'; var_dump($_POST); echo '</pre>';
}
else {
	echo "no session variables";
}*/
?>	

<head>
	<title>KittySpinny</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
<?php

	//msg used to display if incorrect username/password set
	$msg = '';
	
	//checks that username and password fields have been entered via the form
	if (isset($_POST['login']) && !empty($_POST['username']) && !empty($_POST['password'])) {
		/*
		Checks that it has correct username and password, these are probably usually stored
		in a database, but I think this is fine now. We could create another table if we get
		bored
		*/
		if ($_POST['username'] == 'kittySpinny@kitty.com' && 	$_POST['password'] == 'kitty123') {
			//stores the username in session in case we'd like to display it in other places
			$_SESSION['username'] = 'kittySpinny@kitty.com';
			//redirects to new page on successful login, page1.php is just my test page
			echo "<script> window.location.assign('page1.php'); </script>";
		 } 
		 else {
			$msg = 'Wrong username or password';
 		}
	}
?>

</div>
<div class = "container">
<div class="col-md-12">
  <form class = "form-signin" role = "form" method = "post">
		<!--Displays message here if wrong username/password, can be styled-->
		<h4 class = "form-signin-heading"><?php echo $msg; ?></h4>
		<input type = "text" class = "form-control" name = "username" placeholder = "Username"	required autofocus></br>
		<input type = "password" class = "form-control" name = "password" placeholder = "Password" required>
		<button class = "btn btn-lg btn-primary btn-block" type = "submit" name = "login">Login</button>
	</form>	
</div>
</div>
</body>
</html>